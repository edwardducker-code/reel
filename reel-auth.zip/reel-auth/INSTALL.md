# REEL Auth Upgrade — Install Instructions

## Step 1 — Install Supabase packages
Run this in your terminal:

```bash
cd ~/Desktop/reel && npm install @supabase/supabase-js @supabase/ssr
```

## Step 2 — Copy the new/changed files
Unzip this folder and copy these files into ~/Desktop/reel:

- app/lib/supabase.js          → NEW
- app/AuthModal.jsx             → NEW
- app/watchlistHelpers.js       → NEW
- app/api/auth/callback/route.js → NEW
- app/page.tsx                  → REPLACE existing
- app/MyReel.jsx                → REPLACE existing
- .env.local                    → REPLACE existing (or create if missing)

## Step 3 — Update TmdbCard to use Supabase save
Open app/TmdbCard.jsx in Cursor and paste this prompt:

"Update the save button in TmdbCard.jsx so that:
1. It imports { saveFilmToReel } from './watchlistHelpers'
2. It accepts a `user` prop
3. When the save button is clicked:
   - If user is null, call a prop called onSignIn()
   - If user exists, call saveFilmToReel(filmData, user.id) where filmData = { title, year, director, poster }
   - Show 'Saved!' on success, 'Already saved' if alreadySaved, or the error message
4. Pass user and onSignIn through from ChatApp"

## Step 4 — Add env variables to Vercel
Go to Vercel → your reel project → Settings → Environment Variables
Add these two (tick Production, Preview, AND Development for both):

Name: NEXT_PUBLIC_SUPABASE_URL
Value: https://sehnkwlhsmtuftzkhyvk.supabase.co

Name: NEXT_PUBLIC_SUPABASE_ANON_KEY
Value: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNlaG5rd2xoc210dWZ0emhreXZrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODExNjc0NTIsImV4cCI6MjA5Njc0MzQ1Mn0.EA5IiN_92XM0VP8LZznZuas2EkeK7lclG4a04KXSxo4

## Step 5 — Test locally
```bash
cd ~/Desktop/reel && npm run build
```
Fix any errors (usually just prop warnings), then:
```bash
npm run dev
```
Try signing up with your email, saving a film, checking My Reel.

## Step 6 — Push to Vercel
```bash
cd ~/Desktop/reel && git add -A && git commit -m "feat: add user auth with Supabase" && git push
```

## What's now gated behind login
- My Reel (watchlist) — clicking it without an account shows the auth modal
- Saving films from TmdbCards — clicking Save without an account prompts sign in
- Guests can still chat and get recommendations freely
